@echo off
set outputfolder=%1
if "%outputfolder%" NEQ "" (
  if "%outputfolder:~-1%" NEQ "\" ( 
    set outputfolder=%outputfolder%\
  )
)
REM Wix build command
wix.exe build -platform x64 -out %outputfolder%\MsiSetup5.msi -outputType Package -pdb %outputfolder%\MsiSetup5.wixpdb -pdbType full -d SdkFeatureBandVersion=10.0.100 -d ProductLanguage=1033 -d "Manufacturer=Microsoft Corporation" -d MajorVersion=10 -d MinorVersion=0 -d InstallerVersion=200 -d "SdkBrandName=Microsoft .NET SDK 10.0.100-dev" -d "SdkPlatformBrandName=Microsoft .NET SDK 10.0.100-dev (x64)" -d NativeMachine_x86=332 -d NativeMachine_x64=34404 -d NativeMachine_arm64=43620 -d Version=10.0.100-dev -d ProductVersion=40.0.0 -d BundleVersion=42.42.42.42424 -d DotnetSrc=D:\gitsb\sdk\artifacts\obj\sdk-installer\Debug -d "ProductName=Microsoft .NET Toolset 10.0.100-dev (x64)" -d DependencyKeyName=Dotnet_CLI -d UpgradeCode=4c74bd6d-50c8-4341-bf3b-57cff4407a66 -d SolutionDir=. -d SolutionExt=.sln -d SolutionFileName=sdk.sln -d SolutionName=sdk -d SolutionPath=sdk.sln -d Configuration=Debug -d OutDir=%outputfolder% -d InstallerPlatform=x64 -d Platform=x64 -d ProjectDir=. -d ProjectExt=.wixproj -d ProjectFileName=MsiSetup5.wixproj -d ProjectName=toolset -d ProjectPath=MsiSetup5.wixproj -d TargetDir=%outputfolder% -d TargetExt=.msi -d TargetFileName=MsiSetup5.msi -d TargetName=MsiSetup5 -d TargetPath=%outputfolder%\MsiSetup5.msi -ext WixToolset.Util.wixext.dll\WixToolset.Util.wixext.dll -ext WixToolset.UI.wixext.dll\WixToolset.UI.wixext.dll -ext WixToolset.Dependency.wixext.dll\WixToolset.Dependency.wixext.dll -intermediatefolder %outputfolder% -trackingfile %outputfolder%\MsiSetup5.wixproj.BindTracking-neutral.txt -nologo -wx directories.wxs product.wxs
